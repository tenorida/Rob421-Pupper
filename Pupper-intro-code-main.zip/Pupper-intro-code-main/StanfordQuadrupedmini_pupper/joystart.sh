sleep 15
systemctl restart joystick
